Reminder: Add the jar file here when building the package.
